from django.apps import AppConfig


class CurrencyCountryConfig(AppConfig):
    name = 'currency_country'
